﻿using Hotels.Commands;
using Hotels.Models;
using Hotels.ViewModels;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
namespace HOTELS.ViewModels.Admin_viewmodels
{
    partial class AdminUsersTableWindowViewModel : BaseViewModel
    {
        private readonly HotelsContext context = new HotelsContext();

        private ObservableCollection<USERS> usersList = null;
        public ObservableCollection<USERS> UsersList
        {
            get => usersList;
            set => Set(ref usersList, value);
        }
        public AdminUsersTableWindowViewModel()
        {
            UsersList = new ObservableCollection<USERS>(context.USERS);
        }
    }
}
